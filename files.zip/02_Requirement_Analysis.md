# FitBuddy – Requirement Analysis Phase

## 1. Functional Requirements
| ID | Requirement |
|---|---|
| FR1 | Accept name, user ID, age, weight, goal, intensity (low/medium/high) via form |
| FR2 | Generate a 7-day plan (warm-up 5–10 min, main workout with sets/reps, cooldown) using Gemini Pro |
| FR3 | Generate a concise nutrition/recovery tip using Gemini Flash |
| FR4 | Accept feedback with user ID and regenerate the plan |
| FR5 | Store user details, original plan and updated plan separately |
| FR6 | Admin page listing all users with original and updated plans |
| FR7 | Expose API endpoints (documented at `/docs`) |

## 2. Non-Functional Requirements
- **Performance:** near real-time responses (Flash for fast tips)
- **Usability:** clean, responsive, mobile-friendly UI
- **Reliability:** AI errors caught and returned gracefully
- **Security:** API key in environment variable (`.env`), never hard-coded
- **Maintainability:** modular files (routes, database, generators, schemas)
- **Portability:** runs locally with Uvicorn; cloud-ready later

## 3. Technical Requirements
| Layer | Technology |
|---|---|
| Backend | Python, FastAPI, Uvicorn |
| AI | Google Generative AI SDK (Gemini Pro, Flash) |
| Database | SQLite with SQLAlchemy ORM |
| Frontend | HTML, CSS, Jinja2 templates |
| Validation | Pydantic (`UserInput`, `FeedbackRequest`) |
| Tools | pip, virtualenv, Git, python-dotenv |

## 4. Data Requirements
- **User:** id, name, age, weight, goal, intensity, schedule
- **WorkoutPlan:** user_id, original_plan, updated_plan

## 5. User Roles
- **User:** submits details, views plan and tip, sends feedback
- **Admin/Coach:** views all users and plan versions

## 6. Constraints & Assumptions
- Requires internet access and a valid Gemini API key
- Single-machine SQLite storage
- AI output is guidance, not medical advice
- Plan rendered as preformatted text

## 7. Pre-requisite Skills
FastAPI, Gemini API, HTML/CSS/Jinja2, Python, Git, SQLAlchemy/SQLite, virtualenv, Uvicorn.
