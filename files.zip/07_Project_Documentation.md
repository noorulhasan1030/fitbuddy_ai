# FitBuddy – Project Documentation Phase

## 1. Overview
FitBuddy is a FastAPI web app that uses Google Gemini Pro and Flash to generate personalized 7-day workout plans, nutrition/recovery tips, and feedback-based plan updates, with SQLite storage and an admin dashboard.

## 2. Installation Guide
1. Install Python and pip.
2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate        # Windows: venv\Scripts\activate
   ```
3. Install dependencies: `pip install -r requirements.txt`
4. Create `.env` with `GOOGLE_API_KEY=your_gemini_api_key_here`
5. Start the server: `uvicorn app.main:app --reload`
6. Open http://127.0.0.1:8000 (API docs at `/docs`).

## 3. User Guide
| Task | How |
|---|---|
| Get a plan | Fill name, user ID, age, weight, goal, intensity, then click **Generate Plan** |
| Read tip | Shown below the plan |
| Update plan | Open the feedback form, enter the same user ID and your feedback |
| Admin review | Visit `/view-all-users` |

## 4. API Reference
| Endpoint | Method | Input | Output |
|---|---|---|---|
| `/` | GET | none | Home page |
| `/generate-workout` | POST (form) | username, user_id, age, weight, goal, intensity | result.html |
| `/generate-workout/gemini` | POST (JSON) | goal, intensity | model name, workout_plan |
| `/nutrition-tip` | GET | goal | goal, nutrition_tip |
| `/generate-plan` | POST (JSON) | UserInput | message, workout_plan |
| `/update-plan/{user_id}` | POST (JSON) | feedback | updated_plan |
| `/submit-feedback` | POST (form) | user_id, feedback | result.html |
| `/view-all-users` | GET | none | all_users.html |

## 5. Code Structure
See the Project Design document for the file layout. Key functions: `generate_workout_gemini`, `generate_nutrition_tip_with_flash`, `update_workout_plan`, `save_user`, `save_plan`, `update_plan`, `get_original_plan`, `get_user`.

## 6. Configuration
| Variable | Purpose |
|---|---|
| `GOOGLE_API_KEY` | Gemini authentication |
| Model names | Set in the generator files; update when models are retired |

## 7. Troubleshooting
| Problem | Fix |
|---|---|
| "Error: ..." in place of a plan | Check API key, internet, model name |
| Server will not start | Confirm module path (`app.main:app` vs `main:app`) and activated venv |
| Template not found | Check `templates` directory path in `Jinja2Templates` |
| Feedback says plan not found | Use the same user ID as when the plan was generated |

## 8. Limitations & Future Work
Cloud deployment, authentication, progress tracking, rendered markdown plans, multiple plans per user, delete-user admin action.

## 9. Disclaimer
Plans are AI-generated general guidance, not medical advice. Consult a doctor or trainer before starting a new routine.
