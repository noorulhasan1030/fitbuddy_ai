# FitBuddy – Project Design Phase

## 1. Architecture
```
User (Browser)
      |
FastAPI Backend (app/main.py)
      |-- HTML Templating (Jinja2 + CSS): index.html
      |-- Workout Logic (routes.py + AI): result.html
      |-- Admin Panel (/view-all-users): all_users.html
      |
Gemini Pro & Flash APIs
      |
AI Generators (gemini_generator.py, gemini_flash_generator.py, updated_plan.py)
      |
SQLite + SQLAlchemy (fitbuddy.db): users, plans
```

## 2. Folder Structure
```
fitbuddy/
  requirements.txt
  app/ main.py, routes.py, database.py, schemas.py,
       gemini_generator.py, gemini_flash_generator.py,
       updated_plan.py, nutrition.py (optional)
  templates/ index.html, result.html, all_users.html
  static/images/ gym-bg.jpg
  fitbuddy.db
```

## 3. Module Responsibilities
| Module | Role |
|---|---|
| main.py | App entry, mounts static files and router |
| routes.py | Route handlers bridging UI, AI and DB |
| database.py | SQLAlchemy models; save/get/update functions |
| schemas.py | Pydantic validation |
| gemini_generator.py | `generate_workout_gemini()` via Gemini Pro |
| gemini_flash_generator.py | `generate_nutrition_tip_with_flash()` via Flash |
| updated_plan.py | `update_workout_plan()` via Gemini Pro |

## 4. Routes
| Route | Method | Purpose |
|---|---|---|
| `/` | GET | Input form |
| `/generate-workout` | POST | Plan + tip, save, render result |
| `/submit-feedback` | POST | Revise plan, save, render |
| `/view-all-users` | GET | Admin dashboard |
| `/nutrition-tip` | GET | Tip API by goal |
| `/generate-plan`, `/update-plan/{user_id}` | POST | JSON API variants |

## 5. Data Design
**users:** id (PK), name, age, weight, goal, intensity, schedule
**plans:** user_id (FK), original_plan, updated_plan (separate field keeps both versions)

## 6. Data Flow
1. Form submit -> validate -> `save_user`
2. Gemini Pro creates plan -> `save_plan`
3. Gemini Flash creates tip -> render `result.html`
4. Feedback -> load original -> Gemini Pro revises -> `update_plan` -> render

## 7. AI Prompt Design
- **Plan:** trainer persona, goal + intensity, enforced format (Day 1: Warm-up / Main Workout / Cooldown ... Day 7)
- **Tip:** one practical, friendly tip for the goal
- **Update:** original plan + feedback; change only relevant parts, keep format

## 8. UI Design
Gym-themed background, Roboto font, Flexbox centered cards, media queries, hover buttons, dark-background-friendly colors, `<pre>` blocks for plans.
