# FitBuddy – Project Demonstration Phase

## 1. Demo Goal
Show the complete flow: input -> AI plan -> nutrition tip -> feedback update -> admin review (about 8-10 minutes).

## 2. Pre-Demo Checklist
- Virtual environment active, dependencies installed
- `GOOGLE_API_KEY` set in `.env`
- Server running: `uvicorn app.main:app --reload`
- Browser tabs: `/`, `/docs`, `/view-all-users`
- Backup screenshots ready in case of network or API issues

## 3. Demo Script
| Step | Time | Action | Talking point |
|---|---|---|---|
| 1 | 1 min | Introduce problem and solution | Generic plans do not adapt; FitBuddy personalizes with Gemini |
| 2 | 1 min | Show architecture | FastAPI, Gemini Pro/Flash, SQLite, Jinja2 |
| 3 | 1 min | Open home page | Six input fields, gym-themed UI |
| 4 | 2 min | Submit sample user (Name: xyz, ID: 10, Age: 20, 70 kg, "lose belly fat and gain muscles", High) | Gemini Pro builds a 7-day plan with warm-up, workout, cooldown |
| 5 | 1 min | Show nutrition tip | Gemini Flash gives a fast, goal-based tip (e.g. prioritize protein) |
| 6 | 2 min | Submit feedback with ID 10: "include more rest days" or "add yoga" | Plan is regenerated; confirmation message appears |
| 7 | 1 min | Open `/view-all-users` | Original vs. updated plan side by side for coaches |
| 8 | 1 min | Show `/docs` | API endpoints are testable |

## 4. Key Highlights
- Structured AI output with minimal prompt tuning
- Two models, each matched to its task (Pro for depth, Flash for speed)
- Feedback loop that preserves both plan versions
- Coach/admin oversight
- Simple local setup

## 5. Expected Questions & Answers
| Question | Answer |
|---|---|
| Why Gemini over Hugging Face models? | No GPU hosting or fine-tuning needed; API-based; reliable structured output |
| How is data stored? | SQLite via SQLAlchemy; original and updated plans in separate fields |
| How is the API key protected? | Environment variable / `.env` |
| Is the advice medically safe? | General guidance only; disclaimer and doctor consultation advised |
| What next? | Cloud deployment, login, progress tracking, better plan rendering |

## 6. Conclusion Slide Points
FitBuddy combines generative AI, a clean web UI and a persistent backend into an adaptive fitness assistant for both individuals and coaches.

## 7. Contingency
If the API fails, show saved screenshots (home page, plan, tip, feedback confirmation, admin table) and walk through the code of `generate_workout_gemini()` and `/submit-feedback`.
