# FitBuddy – Project Planning Phase

## 1. Objective & Scope
**Objective:** deliver a locally deployable AI fitness plan generator with feedback and admin features.
**In scope:** plan generation, nutrition tip, feedback update, storage, admin view, local deployment.
**Out of scope (future):** cloud hosting, authentication, progress charts.

## 2. Milestones & Activities
| Milestone | Activities | Deliverable |
|---|---|---|
| 1. Model selection & architecture | Research models, define architecture, set up environment | Chosen models, folder structure |
| 2. Core functionality | Generators, DB functions, FastAPI backend | Working AI and storage modules |
| 3. routes.py | Core route handlers | Complete routing layer |
| 4. Frontend | UI design, Jinja2 templates | Three templates |
| 5. Deployment | Local setup, testing and verification | Running app at 127.0.0.1:8000 |

## 3. Suggested Timeline (4 weeks)
| Week | Focus |
|---|---|
| 1 | Milestone 1 and start of Milestone 2 |
| 2 | Finish Milestone 2, Milestone 3 |
| 3 | Milestone 4 (frontend) |
| 4 | Milestone 5, testing, documentation, demo |

## 4. Roles
| Role | Responsibility |
|---|---|
| Backend developer | FastAPI, routes, DB |
| AI/prompt engineer | Gemini prompts and integration |
| Frontend developer | Templates and CSS |
| Tester / documenter | Test cases, report, demo |

(A small team can combine roles.)

## 5. Resources
Python, FastAPI, Uvicorn, SQLAlchemy, google-generativeai, Jinja2, Git, Gemini API key, gym background image.

## 6. Risk Plan
| Risk | Mitigation |
|---|---|
| API key leakage | `.env` file, kept out of Git |
| Model errors or rate limits | try/except with friendly messages, retry |
| Model deprecation (Gemini 1.5 names) | Keep model name in one config variable and update to a current Gemini model |
| Unsafe or inappropriate advice | Disclaimer, consult-a-doctor note in prompts |
| Inconsistent AI format | Strict format instruction in prompt |
| Duplicate user IDs | Update-if-exists logic in `save_user` |

## 7. Tracking
Git commits per milestone, checklist per activity, review at end of each week.
