# FitBuddy – Project Testing Phase

## 1. Test Strategy
Manual functional testing through the browser and `/docs` (Swagger), plus basic error and UI checks. Environment: local, Uvicorn at 127.0.0.1:8000, valid Gemini key.

## 2. Test Cases
| ID | Scenario | Steps | Expected Result |
|---|---|---|---|
| TC01 | Home page loads | Open `/` | Form with 6 fields shown |
| TC02 | Generate plan | Submit valid details (e.g. goal "lose belly fat and gain muscles", High) | Result page shows user info, 7-day plan, tip |
| TC03 | Plan format | Review plan | Each day has warm-up, main workout, cooldown |
| TC04 | Nutrition tip | Submit form or call `/nutrition-tip?goal=muscle gain` | Concise, relevant tip |
| TC05 | Feedback update | Enter same user ID and "include more rest days" | Confirmation shown, plan revised |
| TC06 | Both versions kept | Open `/view-all-users` | Original and updated plans in separate columns |
| TC07 | Unknown user feedback | Submit feedback for nonexistent ID | "Original plan not found" error |
| TC08 | Duplicate user ID | Submit same ID twice with new details | User record updated, no crash |
| TC09 | Invalid input | Leave fields empty, enter text as age | Validation error |
| TC10 | AI failure | Use invalid API key | Error message, no server crash |
| TC11 | Admin with no update | Check user without feedback | "Not updated" displayed |
| TC12 | Responsive UI | Resize to mobile width | Layout adapts |
| TC13 | API docs | Open `/docs` | All endpoints listed and testable |

## 3. Observed Sample Results (from project demo)
- Plan for a 20-year-old, 70 kg, High intensity user rendered a full 7-day plan with notes.
- Nutrition tip prioritized protein with food examples.
- Feedback produced the message "Your plan has been updated based on your feedback!"
- Admin table showed the updated plan with added yoga/stretch guidance.

## 4. Known Issues / Improvements
| Issue | Suggestion |
|---|---|
| Plan shown as raw markdown asterisks in `<pre>` | Render markdown or request JSON output |
| Feedback overwrites only latest update | Add version history |
| Goal is free text | Use a dropdown or validation |
| Only the first plan per user is fetched | Support multiple plans per user |
| Admin page unprotected | Add authentication |
| Safety | Add health disclaimer and age/weight sanity checks |

## 5. Exit Criteria
All core cases (TC01-TC08) pass, with no unhandled exceptions.
