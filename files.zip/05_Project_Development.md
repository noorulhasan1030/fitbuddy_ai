# FitBuddy – Project Development Phase

## 1. Environment Setup
```bash
python -m venv fitbuddy-env
fitbuddy-env\Scripts\activate          # Windows
pip install fastapi uvicorn jinja2 sqlalchemy python-multipart google-generativeai python-dotenv
```
`.env`: `GOOGLE_API_KEY=your_gemini_api_key_here`

## 2. Core Modules
**Workout generation** (`gemini_generator.py`): `generate_workout_gemini(user_input)` builds a trainer-persona prompt with goal and intensity, requires Day 1-7 with Warm-up / Main Workout / Cooldown, calls `model.generate_content()` and returns text (errors are caught).

**Nutrition tip** (`gemini_flash_generator.py`): `generate_nutrition_tip_with_flash(goal)` asks Flash for one practical, friendly tip.

**Plan update** (`updated_plan.py`): `update_workout_plan(original_plan, user_feedback)` sends both to Gemini Pro and changes only the relevant parts.

## 3. Database (`database.py`)
| Function | Purpose |
|---|---|
| `save_user()` | Insert or update user |
| `save_plan()` | Store original plan |
| `update_plan()` | Store revised plan in separate field |
| `get_original_plan()`, `get_user()` | Retrieval |

Tables: `users`, `plans` (SQLite via SQLAlchemy).

## 4. Routes (`routes.py`)
- `/` renders `index.html`
- `/generate-workout` reads `Form(...)`, builds `UserInput`, calls both generators, saves user and plan, renders `result.html`
- `/submit-feedback` loads original plan, updates via Gemini Pro, saves, renders result
- `/view-all-users` joins users and plans, renders `all_users.html` (shows "N/A" or "Not updated" when missing)
- JSON APIs: `/generate-workout/gemini`, `/nutrition-tip`, `/generate-plan`, `/update-plan/{user_id}`

## 5. Frontend
- `index.html`: form (name, user ID, age, weight, goal, intensity)
- `result.html`: user info, plan in `<pre>`, tip, feedback form
- `all_users.html`: table with `{% for user in users %}` loop
- Embedded CSS: Flexbox, media queries, rounded inputs, hover buttons, Roboto

## 6. Run
```bash
uvicorn app.main:app --reload
```
App: http://127.0.0.1:8000, API docs: `/docs`.

## 7. Implementation Notes
- Run Uvicorn with the module path that matches the project layout (`app.main:app`).
- Keep model names in one place for easy upgrades.
- Validate numeric inputs (age, weight) and unique user IDs.
