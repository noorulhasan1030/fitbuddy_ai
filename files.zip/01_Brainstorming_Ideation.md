# FitBuddy – Brainstorming & Ideation Phase

## 1. Problem Statement
Most people find it hard to build a structured, goal-specific workout routine. Generic plans ignore age, weight, goal and intensity preference, and hiring a trainer is costly. Existing plans also rarely adapt when a user's needs change.

## 2. Idea
**FitBuddy** is a web app that uses Google Gemini models to generate a personalized 7-day workout plan, a short nutrition/recovery tip, and a revised plan based on user feedback. Coaches get an admin dashboard to see all users and plans.

## 3. Target Users
| User | Need |
|---|---|
| Beginners / general users | Simple, structured routine |
| Gym-goers | Goal-specific plans (weight loss, muscle gain) |
| Coaches / trainers | One view of many clients' plans |

## 4. Brainstormed Features
- Personalized 7-day plan (warm-up, main workout, cooldown)
- Nutrition / recovery tip by goal
- Feedback-based plan regeneration ("more cardio", "add yoga")
- Persistent storage of users and both plan versions
- Admin dashboard (view-all-users)
- REST endpoints plus an HTML interface

## 5. Technology Options Considered
| Option | Verdict |
|---|---|
| Hugging Face models (T5, BART, DistilBERT, Bloom) | Rejected: need GPU hosting, fine-tuning, heavy prompting |
| Gemini Pro + Gemini Flash (API) | **Selected**: easy FastAPI integration, structured output, low prompt tuning |

## 6. Value Proposition
Affordable, instant, adaptive fitness guidance with oversight for coaches.

## 7. Scenarios Identified
1. User enters details and gets a 7-day plan.
2. User gives feedback and the plan is regenerated.
3. User requests a nutrition/recovery tip.
4. Admin views all users and original vs. updated plans.

## 8. Success Criteria
Plans generated in real time, feedback updates saved without losing the original, admin can review all records.
